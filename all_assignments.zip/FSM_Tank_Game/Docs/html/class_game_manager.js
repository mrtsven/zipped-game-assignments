var class_game_manager =
[
    [ "gameSpeed", "class_game_manager.html#a6ec34c6508050b485abcc52aa8751743", null ]
];