var class_dead_state =
[
    [ "DeadState", "class_dead_state.html#a3aa63ea615e7a9bf420fab57f71d0afb", null ],
    [ "Act", "class_dead_state.html#a87c7964d7e213375c98c82d564312267", null ],
    [ "Reason", "class_dead_state.html#ae20763ccd45e8e1ad18d0e8379eb5e35", null ]
];