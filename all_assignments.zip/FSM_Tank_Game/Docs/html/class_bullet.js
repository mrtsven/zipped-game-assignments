var class_bullet =
[
    [ "damage", "class_bullet.html#a30560d42f8615865e287def189618e31", null ],
    [ "Explosion", "class_bullet.html#a86ecce94fa0717e4fe1f80b385243f4c", null ],
    [ "LifeTime", "class_bullet.html#a7608b55613fe80fd85a587482945037c", null ],
    [ "Speed", "class_bullet.html#a860cc71558c0a388a535127125faf5e1", null ]
];