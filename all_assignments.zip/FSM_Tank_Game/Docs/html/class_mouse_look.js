var class_mouse_look =
[
    [ "RotationAxes", "class_mouse_look.html#a3abd7cc36564223c7f8fafd4da46783d", [
      [ "MouseXAndY", "class_mouse_look.html#a3abd7cc36564223c7f8fafd4da46783da109431b32c091e8a7ad541546c66c522", null ],
      [ "MouseX", "class_mouse_look.html#a3abd7cc36564223c7f8fafd4da46783dabf27c48f8a38ed19eeeba089dd8d3ba1", null ],
      [ "MouseY", "class_mouse_look.html#a3abd7cc36564223c7f8fafd4da46783da73843207a289db41b16a5bb8254ca425", null ]
    ] ],
    [ "axes", "class_mouse_look.html#aa19fe8b976e2dc940a1298c37ee8e0ee", null ],
    [ "maximumX", "class_mouse_look.html#adfd1966b92475d68b1d58394594486fa", null ],
    [ "maximumY", "class_mouse_look.html#a6f14d5c2153dc890f558bd0ace30f2dc", null ],
    [ "minimumX", "class_mouse_look.html#a11dcda2ebdebb86b06472c70d0f0415c", null ],
    [ "minimumY", "class_mouse_look.html#adae14525c0d0439484e002fcd1d9afbe", null ],
    [ "sensitivityX", "class_mouse_look.html#a2d51f6faeb425962a2a54db43d18ced4", null ],
    [ "sensitivityY", "class_mouse_look.html#a6994e854a9ee16c13692171831643a8e", null ]
];