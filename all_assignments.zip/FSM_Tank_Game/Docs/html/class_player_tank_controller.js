var class_player_tank_controller =
[
    [ "Bullet", "class_player_tank_controller.html#afe56cab95748b6b09da2be2d098cb05c", null ],
    [ "elapsedTime", "class_player_tank_controller.html#a5d4c77049184a8c1906652e4f5ad8fe2", null ],
    [ "shootRate", "class_player_tank_controller.html#ada85051d23bb9c8e58d883b978f72f9f", null ]
];