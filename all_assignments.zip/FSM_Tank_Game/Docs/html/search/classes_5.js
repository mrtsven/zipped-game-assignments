var searchData=
[
  ['gamemanager',['GameManager',['../class_game_manager.html',1,'']]]
];
