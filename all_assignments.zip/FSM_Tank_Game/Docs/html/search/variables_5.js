var searchData=
[
  ['gamespeed',['gameSpeed',['../class_game_manager.html#a6ec34c6508050b485abcc52aa8751743',1,'GameManager']]]
];
