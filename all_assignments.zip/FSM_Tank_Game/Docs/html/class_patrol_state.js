var class_patrol_state =
[
    [ "PatrolState", "class_patrol_state.html#a26d27ef886960648851d05a65f239bf1", null ],
    [ "Act", "class_patrol_state.html#a4135d0e662f457583a5ad6ff6c403a4a", null ],
    [ "Reason", "class_patrol_state.html#a218d2e0bd129c2406cc745c1fb2a4a2a", null ]
];